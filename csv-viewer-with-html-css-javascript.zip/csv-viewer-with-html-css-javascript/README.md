# CSV Viewer with HTML, CSS & JavaScript

A Pen created on CodePen.io. Original URL: [https://codepen.io/dcode-software/pen/qBbOEdY](https://codepen.io/dcode-software/pen/qBbOEdY).

Taken from my YouTube tutorial:
https://youtu.be/fwyN81KiAWU

In today's video we'll be creating a CSV Viewer that can be used on the web using HTML, CSS & JavaScript.